# Workflows

## `flux2-klein-9b-variant-prompt-workflow.json`

A Flux.2 Klein 9B text-to-image workflow, based on Comfy-Org's official
single-prompt txt2img template, modified so the positive prompt and the
sampler seed are both driven by the **Variant Prompt Builder** node instead
of being typed in manually.

**Requirements to run this workflow:**
1. A working ComfyUI install with the Flux.2 Klein 9B checkpoint, CLIP, and
   VAE already set up (same requirements as the original official
   single-prompt template — this project doesn't change the model setup).
2. The `comfyui-variant-prompt-builder` custom node installed
   (see the [main README](../README.md#installation)).

**What was changed from the original template:**
- The original `CLIPTextEncode` node's `text` input, which used to be typed
  directly, is now connected to the Variant Prompt Builder's `prompt`
  output.
- The `RandomNoise` node's `noise_seed` input is now connected to the
  Variant Prompt Builder's `seed` output, instead of being set by hand.
- Everything else (model loading, sampler, VAE decode, image preview) is
  untouched from the original template.

**Note on saving images:** the workflow ends in a `PreviewImage` node, so
generated images are shown in the ComfyUI UI but not written to disk. If you
want them saved automatically, replace it with a `SaveImage` node.
